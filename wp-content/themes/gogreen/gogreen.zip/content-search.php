<li id="post-<?php the_ID(); ?>">
    <h2><a href="<?php the_permalink(); ?>" title="blog title"><?php the_title(); ?></a></h2>
    <?php the_excerpt(); ?>
</li>