<div class="col-right">
	<?php dynamic_sidebar('sidebar-1'); ?>
</div>