<form method="get" id="searchform" action="<?php echo home_url(''); ?>/">
    <input type="search" placeholder="Search Here" value="<?php echo get_search_query();  ?>" id="s" name="s" >
</form>